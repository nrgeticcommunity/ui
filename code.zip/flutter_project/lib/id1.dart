import "package:flutter/material.dart";
import "package:flutter_screenutil/flutter_screenutil.dart";

class ID1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, designSize: Size(360, 800));

    return Scaffold(
        backgroundColor: Color(0xFFF5F5F5),
        body: SafeArea(
            child: SingleChildScrollView(
                child: Stack(children: <Widget>[
          Container(
              margin: EdgeInsets.only(top: 571.h, left: 122.w),
              width: 116.w,
              child: Text("NERGETIC",
                  textAlign: TextAlign.left,
                  style: TextStyle(
                      fontFamily: "Poppins",
                      fontSize: 24.sp,
                      color: Color(0xFF50C878)))),
          Container(
              margin: EdgeInsets.only(top: 757.h, left: 12.w),
              height: 8.h,
              width: 337.w,
              decoration: BoxDecoration(
                  color: Color(0xFFE9E9E9),
                  borderRadius: BorderRadius.all(Radius.circular(252.w)),
                  boxShadow: [
                    BoxShadow(
                        color: Color(0x40000000),
                        blurRadius: 11.w,
                        offset: Offset(0.w, 4.h))
                  ])),
          Container(
              margin: EdgeInsets.only(top: 757.h, left: 12.w),
              height: 8.h,
              width: 34.w,
              decoration: BoxDecoration(
                  color: Color(0xFF50C878),
                  borderRadius: BorderRadius.all(Radius.circular(252.w)),
                  boxShadow: [
                    BoxShadow(
                        color: Color(0x40000000),
                        blurRadius: 11.w,
                        offset: Offset(0.w, 4.h))
                  ])),
          Container(
              margin: EdgeInsets.only(top: 774.h, left: 154.w),
              width: 52.w,
              child: Text("Loading",
                  textAlign: TextAlign.left,
                  style: TextStyle(
                      fontFamily: "Poppins",
                      fontSize: 13.sp,
                      color: Color(0xFF000000))))
        ]))));
  }
}
